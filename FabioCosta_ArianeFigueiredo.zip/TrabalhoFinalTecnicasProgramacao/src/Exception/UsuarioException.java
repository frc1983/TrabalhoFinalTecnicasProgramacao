package Exception;

public class UsuarioException extends Exception {

    public UsuarioException(String message) {
        super(message);
    }
}
