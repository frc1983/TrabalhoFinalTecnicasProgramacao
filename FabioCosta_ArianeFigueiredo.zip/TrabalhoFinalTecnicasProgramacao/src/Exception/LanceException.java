package Exception;

public class LanceException extends Exception {

    public LanceException(String message) {
        super(message);
    }
}
