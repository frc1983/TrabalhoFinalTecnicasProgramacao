package Exception;

public class BemException extends Exception {

    public BemException(String message) {
        super(message);
    }
}
