package Exception;

public class LoteException extends Exception {

    public LoteException(String message) {
        super(message);
    }
}
