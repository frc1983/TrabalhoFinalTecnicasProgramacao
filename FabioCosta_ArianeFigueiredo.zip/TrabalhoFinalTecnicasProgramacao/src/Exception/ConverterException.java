package Exception;

public class ConverterException extends Exception {

    public ConverterException(String message) {
        super(message);
    }
}
