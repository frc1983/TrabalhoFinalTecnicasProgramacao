package Enumerators;

public class EnumTipoUsuario {
    public static final int COMPRADOR = 1;
    public static final int VENDEDOR = 2;
}
