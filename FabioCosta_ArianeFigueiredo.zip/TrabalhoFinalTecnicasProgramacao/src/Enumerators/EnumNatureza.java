package Enumerators;

public class EnumNatureza {
    public static final int OFERTA = 1;
    public static final int DEMANDA = 2;
}
