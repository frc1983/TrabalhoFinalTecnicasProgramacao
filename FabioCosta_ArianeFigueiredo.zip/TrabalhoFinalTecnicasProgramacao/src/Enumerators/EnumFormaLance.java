package Enumerators;

public class EnumFormaLance {
    public static final int ABERTO = 1;
    public static final int FECHADO = 2;
}
