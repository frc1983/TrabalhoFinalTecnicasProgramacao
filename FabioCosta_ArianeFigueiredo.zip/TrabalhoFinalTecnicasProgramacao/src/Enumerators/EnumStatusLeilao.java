package Enumerators;

public class EnumStatusLeilao {
    public static final int ATIVO = 1;
    public static final int TERMINADO = 2;
}
